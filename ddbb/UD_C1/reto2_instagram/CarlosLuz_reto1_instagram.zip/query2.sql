use instagram_low_cost;
SELECT idFoto
FROM fotos
WHERE year() = 2024 AND idUsuario = 36;
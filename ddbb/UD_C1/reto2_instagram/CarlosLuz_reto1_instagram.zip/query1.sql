use instagram_low_cost;
SELECT idFoto
FROM fotos
WHERE idUsuario = 36;
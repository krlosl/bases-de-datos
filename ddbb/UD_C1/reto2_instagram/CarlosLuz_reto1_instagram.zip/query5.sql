use instagram_low_cost;
SELECT *
FROM reaccionesFotos as rf
WHERE rf.idFoto = 12 AND rf.idUsuario = 45;